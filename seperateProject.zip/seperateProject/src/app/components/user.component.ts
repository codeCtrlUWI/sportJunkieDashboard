import { Component } from '@angular/core';

@Component({
  selector: 'user',
  template:
    `<h1>Hello {{name}}</h1>`,
})
export class UserComponent  {
  name= 'Asshole';
}
